# utils/__init__.py
"""
Utilitários gerais do projeto

Exporta:
- AnimationThread: Thread para animações durante operações
"""

from .animation import AnimationThread

__all__ = ['AnimationThread']